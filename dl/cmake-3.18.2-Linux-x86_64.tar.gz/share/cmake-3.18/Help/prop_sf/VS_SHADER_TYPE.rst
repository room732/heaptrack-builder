VS_SHADER_TYPE
--------------

Set the Visual Studio shader type of a ``.hlsl`` source file.
